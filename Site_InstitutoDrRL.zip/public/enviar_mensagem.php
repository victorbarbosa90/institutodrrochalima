<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$nome = $_POST['nome']; 
echo $nome."<br>";
$email = $_POST['email'];
echo $email."<br>";
$telefone = $_POST['telefone']; 
echo $telefone."<br>";
$assunto = $_POST['assunto']; 
echo $assunto."<br>";
$mensagem = $_POST['mensagem']; 
echo $mensagem."<br>";

$headers  = 'MIME-Version: 1.0'."\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1'."\r\n";
$headers .= 'From: '.$nome.'<'.$email.'>';

$messageHTML = "<p>".$mensagem."</p>";

$enviar = mail("irl@irl.org.br", $assunto, $messageHTML, $headers);

?>

